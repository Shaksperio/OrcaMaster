"""Demonstra continuidade sem modelo externo e sem qualquer envio de mensagem."""
import tempfile
from pathlib import Path
from cowila import AuthContext, PersistentMemory, Cowila


def main():
    # Na integracao real, os IDs e capacidades vêm da sessão autenticada.
    caps=frozenset({'consent.manage','chat.write','chat.read','chat.delete',
                   'memory.write','memory.review','memory.read','assistant.use'})
    ctx=AuthContext('empresa-demo','usuario-demo','assistant',caps)
    with tempfile.TemporaryDirectory() as folder:
        path=str(Path(folder)/'cowila.db')
        memory=PersistentMemory(path)
        memory.set_consent(ctx,True)
        chat=memory.create_session(ctx,project='OrcaMaster')
        memory.append_turn(ctx,chat,'user','Concluimos o motor MCR. Falta analisar a memoria persistente.')
        checkpoint=memory.checkpoint(ctx,chat,
            'OrcaMaster: motor MCR revisado. Proxima tarefa: analisar a memoria persistente. '
            'Lembretes devem usar Jotform; Resend nao foi autorizado.')
        memory.review(ctx,checkpoint,approve=True,reason='Resumo confirmado para este exemplo')
        memory.clear_chat(ctx,chat)
        memory.close()
        print('Chat apagado e armazenamento de memoria reaberto.')
        memory=PersistentMemory(path)
        chat=memory.create_session(ctx,project='OrcaMaster')
        result=Cowila(memory).answer(ctx,'Continue',session_id=chat)
        print(result['answer'])
        print('Historico da nova conversa:',memory.recent_turns(ctx,chat))
        memory.close()

if __name__=='__main__':main()
