"""Benchmark comparavel: rode na pasta do v9 e na do v10 (detecta os recursos disponiveis).

B1 latencia de recall x numero de memorias (corpus adversarial e corpus diverso)
B2 qualidade da recuperacao (acentos, plural, pergunta natural) e abstencao
B3 aprendizado continuo: tarefas sequenciais com EWC (Fisher empirico x exato)
"""
import inspect
import os
import tempfile
import time

import numpy as np

from cowila import AuthContext, PersistentMemory
from mcr_neural import MCRAIEngine

CAPS = frozenset({'consent.manage', 'memory.write', 'memory.read', 'memory.review', 'memory.delete',
                  'chat.write', 'chat.read', 'chat.delete', 'assistant.use'})
CTX = AuthContext('empresa-A', 'usuario-A', 'assistant', CAPS)
V10 = 'fisher_mode' in inspect.signature(MCRAIEngine.__init__).parameters


def insert_raw(db, i, text):
    db.db.execute("INSERT INTO memory VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (f'id{i}', *CTX.scope, '', 'personal', '', text, '[]', 'semantic', 'user_assertion', 'active',
                   0.5, '', 0, None, None, 1.0, 1.0, None, None, f'fp{i}'))
    if hasattr(db, '_index_memory'):
        db._index_memory(f'id{i}', text, [])


def b1():
    print(f"\n[B1] latencia de recall (ms) - {'v10' if V10 else 'v9'}")
    rng = np.random.RandomState(0)
    vocab = [f'termo{j}' for j in range(4000)]
    for corpus in ('adversarial (todas as memorias dividem palavras comuns)', 'diverso (vocabulario de 4000 termos)'):
        print(f"  corpus {corpus}")
        for n in (200, 1000, 3000):
            with tempfile.TemporaryDirectory() as tmp:
                db = PersistentMemory(os.path.join(tmp, 'm.db'))
                db.set_consent(CTX, True)
                with db.transaction():
                    for i in range(n):
                        if corpus.startswith('adv'):
                            text = f'cliente{i} pediu orcamento numero{i} pintura externa fachada'
                        else:
                            text = ' '.join(rng.choice(vocab, size=7))
                        insert_raw(db, i, text)
                if corpus.startswith('adv'):
                    q = 'Qual o orcamento do cliente7 numero7 pintura?'
                else:
                    row = db.db.execute("SELECT text FROM memory WHERE id='id7'").fetchone()[0]
                    q = ' '.join(row.split()[:4])
                db.recall(CTX, q)
                t = time.perf_counter()
                for _ in range(10):
                    hits = db.recall(CTX, q)
                ms = (time.perf_counter() - t) / 10 * 1000
                print(f"    n={n:5d}: {ms:7.2f} ms  (acertos: {len(hits)})")
                db.close()


MEMORIAS = [
    "Concluímos a memória persistente do projeto OrçaMaster",
    "Orçamentos pendentes do cliente Silva",
    "Lembretes devem usar Jotform e não Resend",
    "A fachada do prédio azul será pintada com tinta acrílica Coral",
    "Preferência: respostas curtas e diretas",
    "Reunião com os fornecedores de tinta toda sexta-feira",
    "O cliente Souza prefere pagamento em três parcelas",
    "Prazo de entrega da obra da rua das Flores: 15 de novembro",
    "Os pintores trabalham de segunda a sábado",
    "Textura grafiato aplicada na parede externa",
]
POSITIVAS = [
    ("memoria persistente do projeto OrcaMaster", 0, "sem acento"),
    ("orçamento pendente do cliente Silva", 1, "plural"),
    ("lembrete deve usar Jotform", 2, "plural"),
    ("Qual tinta será usada na fachada do prédio azul?", 3, "pergunta natural"),
    ("cliente Souza prefere pagar em três parcelas", 6, "reformulacao"),
    ("pintor trabalha de segunda a sábado", 8, "plural"),
    ("reuniao com fornecedor de tinta na sexta", 5, "sem acento + plural"),
    ("textura grafiato parede externa", 9, "controle"),
    ("Concluímos a memória persistente do projeto OrçaMaster", 0, "controle (grafia identica)"),
]
NEGATIVAS = ["Quem assassinou Vhariel?", "qual a previsão do tempo em Fortaleza amanhã", "memória", "cliente",
             "tinta preta para cabelo", "pagamento da conta de luz", "Qual o saldo do banco?"]


def b2():
    print(f"\n[B2] qualidade da recuperacao - {'v10' if V10 else 'v9'}")
    with tempfile.TemporaryDirectory() as tmp:
        db = PersistentMemory(os.path.join(tmp, 'm.db'))
        db.set_consent(CTX, True)
        ids = []
        for t in MEMORIAS:
            mid = db.propose(CTX, t)
            db.review(CTX, mid, approve=True, reason='ok')
            ids.append(mid)
        ok = 0
        for q, idx, nota in POSITIVAS:
            hits = db.recall(CTX, q)
            good = bool(hits) and hits[0]['id'] == ids[idx]
            ok += good
            print(f"    {'ACHOU    ' if good else 'NAO ACHOU'} | {nota:28s} | {q}")
        fp = 0
        for q in NEGATIVAS:
            hits = db.recall(CTX, q)
            fp += bool(hits)
            if hits:
                print(f"    FALSO POSITIVO | {q!r} -> {hits[0]['text']!r}")
        print(f"  recall@1 dos positivos: {ok}/{len(POSITIVAS)} | falsos positivos nos negativos: {fp}/{len(NEGATIVAS)}")
        db.close()


def tarefas(seed, k=5, d=8, n=300):
    r = np.random.RandomState(seed)
    out = []
    for t in range(k):
        w = r.normal(size=d)
        def make(m):
            X = r.normal(size=(m, d)); lab = (X @ w > 0).astype(int)
            bits = np.zeros((m, k)); bits[:, t] = 1
            return np.hstack([X, bits]), np.eye(2)[lab]
        out.append((make(n), make(n)))
    return out


def run_cl(lam, mode, seed):
    kw = dict(seed=seed, max_forgetting_pct=100, ewc_lambda_init=lam, state_path=f'/tmp/_bench_{os.getpid()}.json')
    if V10:
        kw['fisher_mode'] = mode
    eng = MCRAIEngine(13, 24, 2, **kw)
    ts = tarefas(100 + seed)
    just_learned = []
    for i, ((Xtr, ytr), (Xte, yte)) in enumerate(ts):
        rec = eng.learn(f't{i}', Xtr, ytr, Xte, yte, epochs=40, lr=0.05)
        just_learned.append(rec['acc_new_task'])
    final = [eng.evaluate(*eng.tasks[f't{i}']) for i in range(len(ts))]
    return float(np.mean(final)), float(np.mean(np.array(just_learned) - np.array(final)))


def b3():
    print(f"\n[B3] aprendizado continuo, 5 tarefas sequenciais, 6 sementes - {'v10' if V10 else 'v9'}")
    print("     (acuracia final media nas 5 tarefas | esquecimento medio = acc logo apos aprender - acc final)")
    conds = [(0.0, 'empirical')] + [(l, m) for l in (300.0, 3000.0, 30000.0) for m in (('empirical', 'exact') if V10 else ('empirical',))]
    for lam, mode in conds:
        res = np.array([run_cl(lam, mode, s) for s in range(6)])
        print(f"    lambda={lam:7.0f} fisher={mode:9s}: acc final {res[:, 0].mean():.4f} +- {res[:, 0].std():.4f} | esquecimento {res[:, 1].mean():+.4f} +- {res[:, 1].std():.4f}")


if __name__ == '__main__':
    b1(); b2(); b3()
