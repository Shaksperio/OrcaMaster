"""Demonstra a etapa de verificacao da v10: o adaptador erra a conta, o Cerebelo recusa e o adaptador corrige.

O 'modelo' abaixo e um substituto de teste: na integracao real, e o adaptador de linguagem da aplicacao.
"""
import tempfile
from pathlib import Path

from cowila import AuthContext, Cowila, PersistentMemory


def main():
    caps = frozenset({'consent.manage', 'memory.write', 'memory.review', 'memory.read', 'assistant.use'})
    ctx = AuthContext('empresa-demo', 'usuario-demo', 'assistant', caps)
    with tempfile.TemporaryDirectory() as folder:
        memory = PersistentMemory(str(Path(folder) / 'cowila.db'))
        memory.set_consent(ctx, True)
        mid = memory.propose(ctx, 'Desconto combinado com o cliente Silva: 15% sobre o orçamento')
        memory.review(ctx, mid, approve=True, reason='Confirmado pelo usuario')
        cowila = Cowila(memory)

        tentativas = iter([
            f'Pelo registro [{mid}], o desconto é 15% de 200 = 35 reais.',   # conta errada
            f'Pelo registro [{mid}], o desconto é 15% de 200 = 30 reais.',   # corrigida apos o feedback
        ])

        def modelo(envelope):
            if envelope['verification_feedback']:
                print('   feedback recebido pelo modelo:', envelope['verification_feedback'])
            return next(tentativas)

        out = cowila.answer_verified(ctx, 'Qual o desconto combinado com o cliente Silva sobre o orçamento?', model=modelo)
        print('Resposta entregue:', out['answer'])
        print('Verificacao:', out['verification']['status'], '| tentativas:', out['verification']['attempts'])
        for f in out['verification']['findings']:
            print('  -', f['kind'], f['status'], '|', f['detail'])
        memory.close()


if __name__ == '__main__':
    main()
