"""
================================================================================
MCR-AI Engine v8 — motor unico integrando:
  1) MCRActivationV6      -> ativacao (bounce matematicamente verificado)
  2) Continual learning    -> EWC (fisher como MEDIA movel, nao soma bruta --
     correcao feita apos testar com 20 tarefas: soma bruta explode o termo
     de penalidade depois de muitas tarefas. Ver nota no metodo learn().)
  3) Replay buffer          -> mistura amostras de tarefas antigas no treino
     da tarefa nova (testado antes: reduziu esquecimento em ~40 pontos
     percentuais na tarefa mais antiga, com 3 tarefas)
  4) Memoria persistente     -> RAG leve, sobrevive entre execucoes
  + autoajuste: mede o proprio esquecimento apos cada tarefa e aumenta
    a protecao (ewc_lambda) sozinho se ultrapassar o limite aceitavel.
================================================================================
"""
import json, os, re, time
import numpy as np
from scipy.optimize import brentq


# ------------------------------------------------------------------ #
# 1) ATIVACAO
# ------------------------------------------------------------------ #
def solve_bounce_gamma(x0, beta, a_min, gamma_search_max=50.0):
    lhs = np.exp(-beta * x0 ** 2) * (1 - 2 * beta * x0 ** 2)
    if lhs <= 0:
        raise ValueError(f"beta={beta} grande demais para x0={x0}. Use beta < {1/(2*x0**2):.4f}.")
    def eq(gamma):
        return a_min * gamma * np.exp(gamma * x0) - lhs
    for g_hi in [1, 2, 5, 10, 20, gamma_search_max]:
        try:
            return brentq(eq, 1e-8, g_hi)
        except ValueError:
            continue
    raise ValueError("gamma nao encontrado.")


class MCRActivationV6:
    def __init__(self, x0=-0.83, beta=0.5, a_min=0.8):
        self.x0, self.beta, self.a_min = x0, beta, a_min
        self.gamma = solve_bounce_gamma(x0, beta, a_min)
        self._verify()

    def _verify(self):
        h = 1e-5
        fp = self.gradient(np.array([self.x0]))[0]
        fpp = (self.gradient(np.array([self.x0 + h]))[0] - self.gradient(np.array([self.x0 - h]))[0]) / (2*h)
        if abs(fp) > 1e-3 or fpp <= 0:
            raise RuntimeError("Auto-verificacao da MCR falhou.")

    def forward(self, x):
        pos = x
        neg = x * np.exp(-self.beta * x**2) + self.a_min * (1.0 - np.exp(self.gamma * x))
        return np.where(x >= 0.0, pos, neg)

    def gradient(self, x):
        pos_grad = np.ones_like(x)
        neg_grad = (np.exp(-self.beta * x**2) * (1.0 - 2.0*self.beta*x**2)
                    - self.a_min * self.gamma * np.exp(self.gamma * x))
        return np.where(x >= 0.0, pos_grad, neg_grad)


# ------------------------------------------------------------------ #
# 2) MEMORIA PERSISTENTE
# ------------------------------------------------------------------ #
_STOPWORDS = {"o","a","os","as","de","da","do","das","dos","e","em","um","uma",
              "no","na","nos","nas","que","qual","quais","com","se","é","foi"}

def _tokenize(text):
    toks = re.findall(r"[a-zA-ZÀ-ÿ0-9_]+", text.lower())
    return [t for t in toks if len(t) > 1 and t not in _STOPWORDS]


class MemoryStore:
    def __init__(self):
        self.entries = []

    def _embed(self, text):
        toks = _tokenize(text)
        vec = {}
        for t in toks:
            vec[t] = vec.get(t, 0) + 1
        norm = np.sqrt(sum(v*v for v in vec.values())) or 1.0
        return {k: v/norm for k, v in vec.items()}

    @staticmethod
    def _cosine(v1, v2):
        common = set(v1) & set(v2)
        return sum(v1[k]*v2[k] for k in common)

    def remember(self, text, meta=None):
        meta = meta or {}
        # Aliases opcionais permitem registrar formas de pergunta conhecidas
        # sem reduzir o limiar global de abstencao.
        aliases = meta.get("aliases", [])
        index_text = text + " " + " ".join(str(a) for a in aliases)
        self.entries.append({"text": text, "vec": self._embed(index_text), "meta": meta})

    def recall(self, query, top_k=3, min_score=0.30,
               min_shared_tokens=2, min_query_coverage=0.70):
        """Recuperacao conservadora: prefere abstencao a falso recall.

        O cosseno sozinho aceita coincidencias acidentais de uma palavra
        (ex.: "Vhariel" em uma pergunta sobre assassinato recuperando uma
        memoria sobre uma espada). Exigimos evidencias independentes:
        similaridade, quantidade minima de tokens compartilhados e cobertura
        minima dos termos da consulta.
        """
        qvec = self._embed(query)
        qtokens = set(qvec)
        if not qtokens:
            return []

        scored = []
        for e in self.entries:
            etokens = set(e["vec"])
            shared = qtokens & etokens
            score = self._cosine(qvec, e["vec"])
            coverage = len(shared) / len(qtokens)
            if (score >= min_score and
                    len(shared) >= min_shared_tokens and
                    coverage >= min_query_coverage):
                scored.append((score, coverage, len(shared), e))

        scored.sort(key=lambda s: (-s[0], -s[1], -s[2]))
        return [(score, e["text"]) for score, _, _, e in scored[:top_k]]

    def to_dict(self):
        return {"entries": self.entries}

    @classmethod
    def from_dict(cls, d):
        m = cls()
        m.entries = d.get("entries", [])
        return m


def softmax(x):
    e = np.exp(x - np.max(x, axis=1, keepdims=True))
    return e / np.sum(e, axis=1, keepdims=True)


# ------------------------------------------------------------------ #
# 3) MOTOR INTEGRADO (EWC com fisher em MEDIA MOVEL + REPLAY + MEMORIA)
# ------------------------------------------------------------------ #
class MCRAIEngine:
    def __init__(self, n_features, n_hidden, n_classes,
                 x0=-0.83, beta=0.5, a_min=0.8, seed=42,
                 max_forgetting_pct=15.0, ewc_lambda_init=300.0,
                 replay_size_per_task=40, replay_ratio=0.3,
                 state_path="mcr_engine_state.json"):
        self.mcr = MCRActivationV6(x0=x0, beta=beta, a_min=a_min)
        self.n_features, self.n_hidden, self.n_classes = n_features, n_hidden, n_classes
        self.max_forgetting_pct = max_forgetting_pct
        self.ewc_lambda_init = ewc_lambda_init
        self.replay_size_per_task = replay_size_per_task
        self.replay_ratio = replay_ratio
        self.state_path = state_path

        r = np.random.RandomState(seed)
        self.W = {
            'W1': r.randn(n_features, n_hidden) * np.sqrt(2.0/n_features),
            'b1': np.zeros((1, n_hidden)),
            'W2': r.randn(n_hidden, n_classes) * np.sqrt(2.0/n_hidden),
            'b2': np.zeros((1, n_classes)),
        }
        self.fisher_accum = None   # MEDIA MOVEL (nao soma) -- evita explosao com muitas tarefas
        self.n_tasks_in_fisher = 0
        self.W_star = None
        self.tasks = {}
        self.replay_buffer = {}
        self.task_history = []
        self.memory = MemoryStore()

        if os.path.exists(state_path):
            self.load()

    def _forward(self, X, W=None):
        W = W or self.W
        z1 = X @ W['W1'] + W['b1']
        a1 = self.mcr.forward(z1)
        p = softmax(a1 @ W['W2'] + W['b2'])
        return z1, a1, p

    def predict(self, X):
        _, _, p = self._forward(X)
        return p

    def evaluate(self, X, y, W=None):
        _, _, p = self._forward(X, W)
        return float(np.mean(np.argmax(p, axis=1) == np.argmax(y, axis=1)))

    def _build_replay_batch(self, batch_size):
        if not self.replay_buffer:
            return None, None
        all_X = np.concatenate([v[0] for v in self.replay_buffer.values()], axis=0)
        all_y = np.concatenate([v[1] for v in self.replay_buffer.values()], axis=0)
        n = min(batch_size, len(all_X))
        idx = np.random.choice(len(all_X), n, replace=False)
        return all_X[idx], all_y[idx]

    def _train_epochs(self, X, y, epochs, lr, batch, ewc_lambda, W_snapshot):
        n = len(X)
        W = {k: v.copy() for k, v in W_snapshot.items()}
        replay_batch_size = max(1, int(batch * self.replay_ratio))

        for ep in range(epochs):
            idx = np.random.permutation(n)
            for i in range(0, n, batch):
                b = idx[i:i+batch]
                Xb, yb = X[b], y[b]

                if self.replay_buffer:
                    Xr, yr = self._build_replay_batch(replay_batch_size)
                    if Xr is not None:
                        Xb = np.concatenate([Xb, Xr], axis=0)
                        yb = np.concatenate([yb, yr], axis=0)

                z1 = Xb @ W['W1'] + W['b1']
                a1 = self.mcr.forward(z1)
                p = softmax(a1 @ W['W2'] + W['b2'])
                dz2 = (p - yb) / len(Xb)
                dW2 = a1.T @ dz2; db2 = np.sum(dz2, axis=0, keepdims=True)
                da1 = dz2 @ W['W2'].T
                dz1 = da1 * self.mcr.gradient(z1)
                dW1 = Xb.T @ dz1; db1 = np.sum(dz1, axis=0, keepdims=True)

                if self.fisher_accum is not None:
                    dW1 += ewc_lambda * self.fisher_accum['W1'] * (W['W1'] - self.W_star['W1'])
                    dW2 += ewc_lambda * self.fisher_accum['W2'] * (W['W2'] - self.W_star['W2'])
                    db1 += ewc_lambda * self.fisher_accum['b1'] * (W['b1'] - self.W_star['b1'])
                    db2 += ewc_lambda * self.fisher_accum['b2'] * (W['b2'] - self.W_star['b2'])

                W['W1'] -= lr*dW1; W['b1'] -= lr*db1
                W['W2'] -= lr*dW2; W['b2'] -= lr*db2
        return W

    def _compute_fisher(self, W, X, y, n_samples=200):
        fisher = {k: np.zeros_like(v) for k, v in W.items()}
        idx = np.random.choice(len(X), min(n_samples, len(X)), replace=False)
        for i in idx:
            x = X[i:i+1]; yt = y[i:i+1]
            z1 = x @ W['W1'] + W['b1']
            a1 = self.mcr.forward(z1)
            p = softmax(a1 @ W['W2'] + W['b2'])
            dz2 = (p - yt)
            dW2 = a1.T @ dz2; db2 = dz2
            da1 = dz2 @ W['W2'].T
            dz1 = da1 * self.mcr.gradient(z1)
            dW1 = x.T @ dz1; db1 = dz1
            fisher['W1'] += dW1**2; fisher['b1'] += db1**2
            fisher['W2'] += dW2**2; fisher['b2'] += db2**2
        for k in fisher: fisher[k] /= len(idx)
        return fisher

    def learn(self, task_name, X_train, y_train, X_test, y_test,
              epochs=40, lr=0.05, batch=32, max_retries=3, ewc_lambda_cap=20000.0):
        acc_before = {name: self.evaluate(Xte, yte) for name, (Xte, yte) in self.tasks.items()}

        ewc_lambda = self.ewc_lambda_init
        attempt = 0
        while True:
            attempt += 1
            W_snapshot = self.W_star if self.W_star is not None else self.W
            W_new = self._train_epochs(X_train, y_train, epochs, lr, batch, ewc_lambda, W_snapshot)

            forgetting, worst = {}, 0.0
            for name, (Xte, yte) in self.tasks.items():
                acc_now = self.evaluate(Xte, yte, W_new)
                drop = (acc_before[name] - acc_now) * 100
                forgetting[name] = round(drop, 2)
                worst = max(worst, drop)

            if worst <= self.max_forgetting_pct or attempt >= max_retries or not self.tasks or ewc_lambda >= ewc_lambda_cap:
                break
            else:
                ewc_lambda = min(ewc_lambda * 3.0, ewc_lambda_cap)

        self.W = W_new
        acc_new_task = self.evaluate(X_test, y_test)

        # MEDIA MOVEL do fisher (nao soma bruta) -- evita que ewc_lambda*fisher
        # exploda numericamente depois de muitas tarefas (bug real que apareceu
        # ao testar com 20 tarefas na versao anterior, que usava soma)
        fisher_new = self._compute_fisher(self.W, X_train, y_train)
        if self.fisher_accum is None:
            self.fisher_accum = fisher_new
        else:
            t = self.n_tasks_in_fisher
            for k in self.fisher_accum:
                self.fisher_accum[k] = (self.fisher_accum[k] * t + fisher_new[k]) / (t + 1)
        self.n_tasks_in_fisher += 1
        self.W_star = {k: v.copy() for k, v in self.W.items()}
        self.tasks[task_name] = (X_test, y_test)

        idx = np.random.choice(len(X_train), min(self.replay_size_per_task, len(X_train)), replace=False)
        self.replay_buffer[task_name] = (X_train[idx].copy(), y_train[idx].copy())

        avg_forgetting = float(np.mean(list(forgetting.values()))) if forgetting else 0.0
        record = {"task": task_name, "attempts": attempt, "ewc_lambda_final": ewc_lambda,
                   "acc_new_task": acc_new_task, "forgetting_pct": forgetting,
                   "avg_forgetting": avg_forgetting, "n_tasks_seen": len(self.tasks)}
        self.task_history.append(record)
        self.memory.remember(
            f"Tarefa '{task_name}' (#{len(self.tasks)}) aprendida com acuracia "
            f"{acc_new_task*100:.2f}%. Esquecimento medio nas tarefas anteriores: "
            f"{avg_forgetting:.2f} pontos percentuais."
        )
        return record

    def remember(self, text, meta=None):
        self.memory.remember(text, meta)

    def ask(self, question, min_score=0.30):
        # Retorna apenas a melhor memoria. Misturar top-3 aumenta o risco de
        # anexar fatos irrelevantes a uma resposta correta.
        hits = self.memory.recall(question, top_k=1, min_score=min_score)
        if not hits:
            return "Não tenho isso registrado na memória — não vou inventar uma resposta."
        score, text = hits[0]
        return f"Com base no que está registrado:\n  [confiança {score:.2f}] {text}\n"

    def save(self):
        def arr(d): return {k: v.tolist() for k, v in d.items()} if d else None
        state = {
            "W": arr(self.W), "fisher_accum": arr(self.fisher_accum),
            "n_tasks_in_fisher": self.n_tasks_in_fisher,
            "W_star": arr(self.W_star), "task_history": self.task_history,
            "memory": self.memory.to_dict(),
            "replay_buffer": {k: [v[0].tolist(), v[1].tolist()] for k, v in self.replay_buffer.items()},
        }
        with open(self.state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

    def load(self):
        with open(self.state_path, encoding="utf-8") as f:
            state = json.load(f)
        def to_np(d): return {k: np.array(v) for k, v in d.items()} if d else None
        self.W = to_np(state["W"])
        self.fisher_accum = to_np(state["fisher_accum"])
        self.n_tasks_in_fisher = state.get("n_tasks_in_fisher", 0)
        self.W_star = to_np(state["W_star"])
        self.task_history = state["task_history"]
        self.memory = MemoryStore.from_dict(state["memory"])
        self.replay_buffer = {k: (np.array(v[0]), np.array(v[1])) for k, v in state.get("replay_buffer", {}).items()}
