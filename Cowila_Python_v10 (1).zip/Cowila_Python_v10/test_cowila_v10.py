"""Testes das mudancas da v10. A suite original (test_cowila.py) continua valendo sem alteracao."""
import glob
import json
import os
import re
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np

from cowila import AuthContext, Cerebelo, Cowila, DeterministicMath, PersistentMemory, parse_number
from mcr_neural import MCRActivationV6, MCRAIEngine, MemoryStore, _tokenize, softmax, solve_bounce_gamma

CAPS = frozenset({'consent.manage', 'memory.write', 'memory.read', 'memory.review', 'memory.delete',
                  'chat.write', 'chat.read', 'chat.delete', 'assistant.use', 'business.read',
                  'feedback.write', 'learning.propose', 'learning.approve'})


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.tmp.name) / 'memory.db')
        self.now = [1000.0]
        self.db = PersistentMemory(self.path, lambda: self.now[0])
        self.ctx = AuthContext('empresa-A', 'usuario-A', 'assistant', CAPS)
        self.db.set_consent(self.ctx, True)
        self.cowila = Cowila(self.db)

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def active(self, text, **kw):
        mid = self.db.propose(self.ctx, text, **kw)
        self.db.review(self.ctx, mid, approve=True, reason='ok')
        return mid


class ActivationTests(unittest.TestCase):
    def test_solver_finds_roots_the_v9_bracket_search_missed(self):
        for x0, b, a in [(-0.83, 0.5, 0.5), (-2.0, 0.05, 3.0), (-3.0, 0.05, 0.8)]:
            g = solve_bounce_gamma(x0, b, a)
            s = b * x0 ** 2
            lhs = np.exp(-s) * (1 - 2 * s)
            self.assertAlmostEqual(a * g * np.exp(g * x0), lhs, places=12)
            MCRActivationV6(x0, b, a)  # e a auto-verificacao (minimo unico) passa
        # (-0.3, 0.2, 0.8): o v9 tambem falhava, mas aqui a raiz existe e e RECUSADA de proposito (a_min*g = 2.02 > 1)
        with self.assertRaises(ValueError):
            solve_bounce_gamma(-0.3, 0.2, 0.8)

    def test_default_gamma_matches_v9_value(self):
        self.assertAlmostEqual(MCRActivationV6().gamma, 0.37671087393678326, places=10)

    def test_rejects_parameters_that_create_a_second_critical_point(self):
        with self.assertRaises(ValueError):
            MCRActivationV6(-0.3, 0.2, 3.0)  # a_min*gamma = 1.05 > 1
        with self.assertRaises(ValueError):
            MCRActivationV6(-0.83, 0.5, 0.1)  # sem raiz real
        with self.assertRaises(ValueError):
            MCRActivationV6(-0.83, 2.0, 0.8)  # beta grande demais

    def test_hessian_matches_finite_difference(self):
        m = MCRActivationV6()
        x = np.linspace(-4, -0.05, 200)
        h = 1e-6
        fd = (m.gradient(x + h) - m.gradient(x - h)) / (2 * h)
        np.testing.assert_allclose(m.hessian(x), fd, atol=1e-6)

    def test_no_overflow_for_large_inputs(self):
        m = MCRActivationV6()
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            out = m.forward(np.array([-1e4, 0.0, 1e4]))
        self.assertTrue(np.isfinite(out).all())


class FisherTests(unittest.TestCase):
    def test_exact_fisher_matches_per_sample_reference(self):
        eng = MCRAIEngine(3, 5, 3, seed=2, state_path='/tmp/_nao_usado_v10.json')
        X = np.random.RandomState(1).normal(size=(30, 3))
        got = eng._fisher_exact(eng.W, X)
        want = {k: np.zeros_like(v) for k, v in eng.W.items()}
        for i in range(len(X)):
            x = X[i:i + 1]
            z1 = x @ eng.W['W1'] + eng.W['b1']
            a1 = eng.mcr.forward(z1)
            p = softmax(a1 @ eng.W['W2'] + eng.W['b2'])
            for c in range(3):
                dz2 = p.copy(); dz2[0, c] -= 1
                dz1 = (dz2 @ eng.W['W2'].T) * eng.mcr.gradient(z1)
                want['W2'] += p[0, c] * (a1.T @ dz2) ** 2
                want['b2'] += p[0, c] * dz2 ** 2
                want['W1'] += p[0, c] * (x.T @ dz1) ** 2
                want['b1'] += p[0, c] * dz1 ** 2
        for k in want:
            np.testing.assert_allclose(got[k], want[k] / len(X), rtol=1e-10, atol=1e-14)

    def test_exact_mode_persists_and_v9_checkpoint_defaults_to_empirical(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 's.json')
            r = np.random.RandomState(3)
            X = r.normal(size=(60, 2)); y = np.eye(2)[(X[:, 0] > 0).astype(int)]
            eng = MCRAIEngine(2, 6, 2, state_path=path, seed=1, max_forgetting_pct=100, fisher_mode='exact')
            eng.learn('t1', X, y, X, y, epochs=5)
            eng.save()
            self.assertEqual(MCRAIEngine(2, 6, 2, state_path=path).fisher_mode, 'exact')
            with open(path, encoding='utf-8') as fh:
                state = json.load(fh)
            state['version'] = 9
            del state['config']['fisher_mode']
            for e in state['memory']['entries']:
                e['vec'] = {'lixo': 1.0}  # vetor de outra tokenizacao
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(state, fh)
            legacy = MCRAIEngine(2, 6, 2, state_path=path)
            self.assertEqual(legacy.fisher_mode, 'empirical')
            self.assertNotIn('lixo', legacy.memory.entries[0]['vec'])
            self.assertIn('t1', legacy.ask('tarefa t1 aprendida').lower() + ' t1')

    def test_invalid_fisher_mode(self):
        with self.assertRaises(ValueError):
            MCRAIEngine(2, 4, 2, fisher_mode='outro', state_path='/tmp/_nao_usado_v10b.json')


class TokenizerTests(unittest.TestCase):
    def test_accents_and_plurals_normalize(self):
        self.assertEqual(_tokenize('Memória'), _tokenize('memoria'))
        self.assertEqual(_tokenize('orçamentos pendentes'), _tokenize('orçamento pendente'))
        self.assertEqual(_tokenize('pintores'), _tokenize('pintor'))
        self.assertEqual(_tokenize('itens'), _tokenize('item'))

    def test_numbers_and_codes_are_untouched(self):
        self.assertEqual(_tokenize('cliente1 numero2'), ['cliente1', 'numero2'])


class RecallTests(Base):
    def test_accent_and_plural_variants_are_found(self):
        self.active('Concluímos a memória persistente do projeto')
        self.active('Orçamentos pendentes do cliente Silva')
        self.assertEqual(len(self.db.recall(self.ctx, 'memoria persistente do projeto')), 1)
        self.assertEqual(len(self.db.recall(self.ctx, 'orçamento pendente do cliente Silva')), 1)

    def test_abstention_is_preserved(self):
        self.active('Vhariel utiliza uma espada ancestral')
        self.active('Jotform e o provedor autorizado para lembretes')
        for q in ('Quem assassinou Vhariel?', 'qual a cor do ceu azul', 'espada', 'Qual o clima de Fortaleza hoje?'):
            self.assertEqual(self.db.recall(self.ctx, q), [], q)

    def test_indexed_recall_equals_exhaustive_scan(self):
        rng = np.random.RandomState(7)
        vocab = [f'palavra{i}' for i in range(35)] + ['orçamento', 'cliente', 'pintura', 'fachada', 'memória']
        texts = [' '.join(rng.choice(vocab, size=int(rng.randint(4, 9)))) for _ in range(150)]
        for t in texts:
            self.active(t)
        embed = MemoryStore()._embed
        rows = self.db.db.execute("SELECT id,text,aliases FROM memory WHERE status='active'").fetchall()
        total = 0
        for _ in range(60):
            q = ' '.join(rng.choice(vocab, size=int(rng.randint(2, 5)))) if rng.rand() < 0.5 else texts[int(rng.randint(150))]
            qv = embed(q)
            want = {}
            for r in rows:
                v = embed(r['text'] + ' ' + ' '.join(json.loads(r['aliases'])))
                shared = set(qv) & set(v)
                score = MemoryStore._cosine(qv, v)
                if qv and score >= 0.30 and len(shared) >= 2 and len(shared) / len(qv) >= 0.70:
                    want[r['id']] = score
            got = {h['id']: h['similarity'] for h in self.db.recall(self.ctx, q, top_k=40)}
            self.assertEqual(set(got), set(want), q)
            for k in want:
                self.assertAlmostEqual(got[k], want[k], places=12)
            total += len(want)
        self.assertGreater(total, 30)  # o teste precisa exercitar acertos de verdade

    def test_index_is_rebuilt_for_a_database_without_it(self):
        mid = self.active('Cowila memoria persistente')
        self.db.db.execute('DROP TABLE memory_token')
        self.db.db.execute('DROP TABLE meta')
        self.db.db.commit()
        self.db.close()
        self.db = PersistentMemory(self.path, lambda: self.now[0])
        self.assertEqual(self.db.recall(self.ctx, 'Cowila memoria persistente')[0]['id'], mid)

    def test_forget_removes_index_entries_and_hits(self):
        mid = self.active('Cowila memoria persistente')
        self.db.forget(self.ctx, mid)
        n = self.db.db.execute('SELECT COUNT(*) FROM memory_token WHERE memory_id=?', (mid,)).fetchone()[0]
        self.assertEqual(n, 0)
        self.assertEqual(self.db.recall(self.ctx, 'Cowila memoria persistente'), [])

    def test_recall_latency_does_not_grow_with_unrelated_memories(self):
        with self.db.transaction():
            for i in range(3000):
                self.db.db.execute(
                    "INSERT INTO memory VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (f'id{i}', *self.ctx.scope, '', 'personal', '', f'cliente{i} pediu orcamento numero{i} pintura externa',
                     '[]', 'semantic', 'user_assertion', 'active', 0.5, '', 0, None, None, 1.0, 1.0, None, None, f'fp{i}'))
                self.db._index_memory(f'id{i}', f'cliente{i} pediu orcamento numero{i} pintura externa', [])
        t = time.perf_counter()
        for _ in range(5):
            hits = self.db.recall(self.ctx, 'Qual o orcamento do cliente7 numero7 pintura?')
        per_call = (time.perf_counter() - t) / 5
        self.assertTrue(any('cliente7 ' in h['text'] for h in hits))
        self.assertLess(per_call, 0.05)  # o v9 levava ~80 ms com 3000 memorias nesta mesma maquina


class SecureDeleteTests(Base):
    MARK = 'MARCADOR-UNICO-DE-PRIVACIDADE-7781'

    def scan(self):
        found = []
        for f in glob.glob(os.path.join(self.tmp.name, 'memory.db*')):
            with open(f, 'rb') as fh:
                if self.MARK.encode() in fh.read():
                    found.append(os.path.basename(f))
        return found

    def test_deleted_text_is_gone_from_every_sqlite_file_with_connection_open(self):
        mid = self.active(self.MARK + ' dado pessoal do cliente')
        sid = self.db.create_session(self.ctx, project='P')
        self.db.append_turn(self.ctx, sid, 'user', 'turno com ' + self.MARK)
        self.assertTrue(self.scan())  # sanidade: o marcador estava gravado
        self.db.forget(self.ctx, mid)
        self.db.clear_chat(self.ctx, sid)
        self.assertEqual(self.scan(), [])

    def test_consent_withdrawal_scrubs_deleted_sessions(self):
        sid = self.db.create_session(self.ctx)
        self.db.append_turn(self.ctx, sid, 'user', 'turno com ' + self.MARK)
        self.db.set_consent(self.ctx, False)
        self.assertEqual(self.scan(), [])


class MathTests(unittest.TestCase):
    def test_errors_are_value_errors(self):
        for e in ('1/0', '0/0', '1 +', '(', ''):
            with self.assertRaises(ValueError, msg=e):
                DeterministicMath.calculate(e)

    def test_positional_formatting(self):
        self.assertEqual(DeterministicMath.calculate('1e2*3')['value'], '300')
        self.assertEqual(DeterministicMath.calculate('0.10*300')['value'], '30')
        self.assertEqual(DeterministicMath.calculate('0.1+0.2')['value'], '0.3')
        self.assertEqual(DeterministicMath.calculate('10/4')['value'], '2.5')
        self.assertEqual(DeterministicMath.calculate('5-5')['value'], '0')
        self.assertEqual(DeterministicMath.geometry(2.5, 4)['area_m2'], '10')


class NeuralGovernanceTests(Base):
    def setUp(self):
        super().setUp()
        r = np.random.RandomState(1)
        self.X = r.normal(size=(40, 2))
        self.y = np.eye(2)[(self.X[:, 0] > 0).astype(int)]
        self.eng = lambda name: MCRAIEngine(2, 8, 2, state_path=os.path.join(self.tmp.name, name), seed=1,
                                            max_forgetting_pct=100, ewc_lambda_init=1)

    def test_failed_proposal_does_not_bind_the_engine_to_the_caller(self):
        c = Cowila(self.db, self.eng('a.json'))
        other = AuthContext('empresa-B', 'usuario-B', 'assistant', CAPS)
        self.db.set_consent(other, True)
        with self.assertRaises(ValueError):
            c.propose_training(self.ctx, 'ruim', self.X, np.full((40, 2), np.nan), self.X, self.y, epochs=1)
        self.assertIsNone(c.neural_scope)
        self.assertIn('candidate_id', c.propose_training(other, 'boa', self.X, self.y, self.X, self.y, epochs=1))

    def test_pending_candidates_are_capped_and_can_be_discarded(self):
        c = Cowila(self.db, self.eng('b.json'))
        ids = [c.propose_training(self.ctx, f't{i}', self.X, self.y, self.X, self.y, epochs=1)['candidate_id']
               for i in range(Cowila.MAX_PENDING_TRAININGS + 4)]
        self.assertEqual(len(c.candidates), Cowila.MAX_PENDING_TRAININGS)
        with self.assertRaises(KeyError):
            c.approve_training(self.ctx, ids[0])  # o mais antigo foi descartado
        c.discard_training(self.ctx, ids[-1])
        self.assertNotIn(ids[-1], c.candidates)
        with self.assertRaises(KeyError):
            c.discard_training(self.ctx, ids[-1])

    def test_candidates_expire(self):
        c = Cowila(self.db, self.eng('c.json'))
        cid = c.propose_training(self.ctx, 't', self.X, self.y, self.X, self.y, epochs=1)['candidate_id']
        self.now[0] += Cowila.TRAINING_TTL_SECONDS + 1
        with self.assertRaises(KeyError):
            c.approve_training(self.ctx, cid)


class ResumeTests(Base):
    def test_bare_yes_resumes_only_in_an_empty_conversation(self):
        sid = self.db.create_session(self.ctx, project='P')
        mid = self.db.checkpoint(self.ctx, sid, 'P: falta revisar a memoria Python.')
        self.db.review(self.ctx, mid, approve=True, reason='ok')
        fresh = self.db.create_session(self.ctx, project='P')
        self.assertEqual([m['id'] for m in self.cowila.context(self.ctx, 'Sim', session_id=fresh)['memories']], [mid])
        self.db.append_turn(self.ctx, fresh, 'user', 'Quero falar de outra coisa')
        self.assertEqual(self.cowila.context(self.ctx, 'Sim', session_id=fresh)['memories'], [])
        self.assertEqual([m['id'] for m in self.cowila.context(self.ctx, 'Continue', session_id=fresh)['memories']], [mid])


class VerifiedAnswerTests(Base):
    def run_model(self, drafts, question='Quanto e 15% de 200?', **kw):
        seen = []

        def model(envelope):
            seen.append(list(envelope['verification_feedback']))
            return drafts[min(len(seen), len(drafts)) - 1]
        out = self.cowila.answer_verified(self.ctx, question, model=model, **kw)
        return out, seen

    def test_refuted_arithmetic_is_regenerated_with_feedback(self):
        out, seen = self.run_model(['200 * 15 / 100 = 35', '200 * 15 / 100 = 30'])
        self.assertEqual(out['verification']['status'], 'verified')
        self.assertEqual(out['verification']['attempts'], 2)
        self.assertEqual(seen[0], [])
        self.assertIn('30', seen[1][0])
        self.assertEqual(out['answer'], '200 * 15 / 100 = 30')

    def test_abstains_when_every_attempt_is_refuted(self):
        out, _ = self.run_model(['2 + 2 = 5'], max_attempts=2)
        self.assertEqual(out['verification']['status'], 'abstained')
        self.assertEqual(out['verification']['attempts'], 2)
        self.assertTrue(out['answer'].startswith('Nao consegui'))
        self.assertNotIn('2 + 2 = 5', out['answer'])
        self.assertEqual(out['verification']['rejected_draft'], '2 + 2 = 5')

    def test_brazilian_number_formats(self):
        for draft, status in (('1.234,50 + 765,50 = 2.000,00', 'verified'), ('1.234,50 + 765,50 = 2.001,00', 'abstained'),
                              ('10 / 3 = 3,33', 'verified'), ('10 / 3 = 3,34', 'abstained'),
                              ('12 x 3 = 36', 'verified'), ('12 × 3 = 37', 'abstained'),
                              ('2 + 2 = 4.', 'verified')):
            out, _ = self.run_model([draft], max_attempts=1)
            self.assertEqual(out['verification']['status'], status, draft)

    def test_percent_of(self):
        self.assertEqual(self.run_model(['15% de 200 é 30'], max_attempts=1)[0]['verification']['status'], 'verified')
        self.assertEqual(self.run_model(['15% de 200 é 35'], max_attempts=1)[0]['verification']['status'], 'abstained')

    def test_ambiguous_numbers_are_unverifiable_not_refuted(self):
        out, _ = self.run_model(['3.141 * 2 = 6.282'], max_attempts=1)
        self.assertEqual(out['verification']['status'], 'unchecked')
        self.assertEqual(out['verification']['findings'][0]['status'], 'unverifiable')
        self.assertIsNone(parse_number('1.234'))
        self.assertEqual(parse_number('1.234.567'), 1234567)

    def test_citations_must_exist_in_context(self):
        mid = self.active('Cowila memoria persistente')
        ok_, _ = self.run_model([f'Registro [{mid}] confirma.'], question='Cowila memoria persistente', max_attempts=1)
        self.assertEqual(ok_['verification']['status'], 'verified')
        fake = '[00000000-0000-4000-8000-000000000000]'
        bad, _ = self.run_model([f'Registro {fake} confirma.'], question='Cowila memoria persistente', max_attempts=1)
        self.assertEqual(bad['verification']['status'], 'abstained')

    def test_claiming_to_remember_without_context_is_refuted(self):
        out, _ = self.run_model(['Eu me lembro que você me disse isso ontem.'], max_attempts=1)
        self.assertEqual(out['verification']['status'], 'abstained')
        for ok_text in ('Não me lembro disso.', 'Eu não lembro desse assunto.', 'Sem registro, não posso confirmar.'):
            self.assertEqual(self.run_model([ok_text], max_attempts=1)[0]['verification']['status'], 'unchecked', ok_text)

    def test_recall_claim_is_accepted_when_context_exists(self):
        self.active('Cowila memoria persistente')
        out, _ = self.run_model(['Eu me lembro: registro de Cowila memoria persistente.'],
                                question='Cowila memoria persistente', max_attempts=1)
        self.assertNotEqual(out['verification']['status'], 'abstained')

    def test_nothing_checkable_is_unchecked_not_verified(self):
        out, _ = self.run_model(['Olá! Como posso ajudar?'], max_attempts=1)
        self.assertEqual(out['verification']['status'], 'unchecked')

    def test_adversarial_long_draft_does_not_hang(self):
        t = time.perf_counter()
        out, _ = self.run_model(['1+' * 12000 + '1'], max_attempts=1)
        self.assertLess(time.perf_counter() - t, 2.0)
        self.assertEqual(out['verification']['status'], 'unchecked')

    def test_argument_validation_and_audit(self):
        with self.assertRaises(ValueError):
            self.cowila.answer_verified(self.ctx, 'x y', model=None)
        with self.assertRaises(ValueError):
            self.cowila.answer_verified(self.ctx, 'x y', model=lambda e: 'ok', max_attempts=9)
        out, _ = self.run_model(['2 + 2 = 4'], max_attempts=1)
        n = self.db.db.execute("SELECT COUNT(*) FROM audit WHERE event='assistant.verified' AND resource=?",
                               (out['response_id'],)).fetchone()[0]
        self.assertEqual(n, 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
