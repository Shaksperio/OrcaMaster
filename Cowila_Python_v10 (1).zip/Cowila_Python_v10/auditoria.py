"""Auditoria: reproduz, com evidencia, os defeitos encontrados no Cowila v9. Rode na pasta de qualquer versao."""
import os, tempfile, time, glob, copy
import numpy as np

from cowila import AuthContext, PersistentMemory, Cowila, DeterministicMath
from mcr_neural import MCRAIEngine, MCRActivationV6, solve_bounce_gamma, softmax

CAPS = frozenset({'consent.manage', 'memory.write', 'memory.read', 'memory.review', 'memory.delete',
                  'chat.write', 'chat.read', 'chat.delete', 'assistant.use', 'business.read',
                  'feedback.write', 'learning.propose', 'learning.approve'})
CTX = AuthContext('empresa-A', 'usuario-A', 'assistant', CAPS)


def novo_db(tmp, clock=None):
    db = PersistentMemory(os.path.join(tmp, 'm.db'), clock or time.time)
    db.set_consent(CTX, True)
    return db


def ativa(db, texto, **kw):
    mid = db.propose(CTX, texto, **kw)
    db.review(CTX, mid, approve=True, reason='ok')
    return mid


def secao(t):
    print(f"\n== {t}")


# E1 ------------------------------------------------------------------
secao("E1  Solver de gamma (brentq com brackets fixos)")
casos = [(-0.3, 0.2, 0.8), (-0.83, 0.5, 0.5), (-2.0, 0.05, 3.0), (-3.0, 0.05, 0.8)]
for x0, b, a in casos:
    try:
        g = solve_bounce_gamma(x0, b, a)
        print(f"  x0={x0} beta={b} a_min={a}: gamma={g:.6f}")
    except ValueError as e:
        print(f"  x0={x0} beta={b} a_min={a}: FALHA -> {e}")
try:
    m = MCRActivationV6(-0.3, 0.2, 3.0)
    print(f"  (-0.3,0.2,3.0) aceita; a_min*gamma = {m.a_min*m.gamma:.3f} (>1 => f'(0-)<0, 2o ponto critico)")
    grid = np.linspace(-8, -1e-6, 100001)
    s = np.sign(m.gradient(grid)); s = s[s != 0]
    print("  cruzamentos de sinal de f' em x<0:", int(np.count_nonzero(np.diff(s))))
except Exception as e:
    print("  (-0.3,0.2,3.0) recusada:", e)

# E2/E3 ---------------------------------------------------------------
secao("E2/E3  Recuperacao com acentos e flexao")
with tempfile.TemporaryDirectory() as tmp:
    db = novo_db(tmp)
    ativa(db, 'Concluímos a memória persistente do projeto')
    ativa(db, 'Orçamentos pendentes do cliente Silva')
    ativa(db, 'Lembretes devem usar Jotform')
    pares = [("memoria persistente do projeto", "acento: consulta sem acento"),
             ("Concluímos a memória persistente do projeto", "mesma grafia (controle)"),
             ("orçamento pendente do cliente Silva", "singular/plural"),
             ("lembrete deve usar Jotform", "singular/plural"),
             ("Qual a memória persistente do projeto?", "pergunta natural")]
    for q, nota in pares:
        print(f"  {'ACHOU ' if db.recall(CTX, q) else 'NAO ACHOU'} | {nota}: {q!r}")
    db.close()

# E4 ------------------------------------------------------------------
secao("E4  Exclusao: o texto some dos arquivos do SQLite?")
MARK = b'MARCADOR-UNICO-DE-PRIVACIDADE-7781'
with tempfile.TemporaryDirectory() as tmp:
    db = novo_db(tmp)
    mid = ativa(db, MARK.decode() + ' dado pessoal do cliente')
    sid = db.create_session(CTX, project='P')
    db.append_turn(CTX, sid, 'user', 'turno com ' + MARK.decode())
    db.forget(CTX, mid)
    db.clear_chat(CTX, sid)
    def varre():
        achou = []
        for f in glob.glob(os.path.join(tmp, 'm.db*')):
            with open(f, 'rb') as fh:
                if MARK in fh.read(): achou.append(os.path.basename(f))
        return achou
    print("  apos forget()+clear_chat(), conexao aberta, arquivos com o marcador:", varre() or "nenhum")
    db.close()
    print("  apos close(), arquivos com o marcador:", varre() or "nenhum")

# E5 ------------------------------------------------------------------
secao("E5  DeterministicMath: erros e formato")
for e in ['1/0', '0/0', '1e2*3', '1_000*2', '10/4', '(1+2)*3']:
    try:
        print(f"  {e!r:10} -> {DeterministicMath.calculate(e)['value']!r}")
    except Exception as ex:
        print(f"  {e!r:10} -> levanta {type(ex).__module__}.{type(ex).__name__} (ValueError? {isinstance(ex, ValueError)})")

# E6/E7 ---------------------------------------------------------------
secao("E6/E7  Escopo neural vinculado por proposta que falhou; candidatos acumulados")
with tempfile.TemporaryDirectory() as tmp:
    db = novo_db(tmp)
    B = AuthContext('empresa-B', 'usuario-B', 'assistant', CAPS); db.set_consent(B, True)
    r = np.random.RandomState(1); X = r.normal(size=(40, 2)); y = np.eye(2)[(X[:, 0] > 0).astype(int)]
    c = Cowila(db, MCRAIEngine(2, 8, 2, state_path=os.path.join(tmp, 's.json'), seed=1,
                               max_forgetting_pct=100, ewc_lambda_init=1))
    try:
        c.propose_training(CTX, 'ruim', X, np.full((40, 2), np.nan), X, y, epochs=2)
    except ValueError as e:
        print("  A propos treino invalido ->", e)
    print("  neural_scope apos a falha:", c.neural_scope)
    try:
        c.propose_training(B, 'valida', X, y, X, y, epochs=2)
        print("  B conseguiu propor treino valido")
    except PermissionError as e:
        print("  B (treino valido) bloqueado ->", e)
    c2 = Cowila(db, MCRAIEngine(2, 8, 2, state_path=os.path.join(tmp, 's2.json'), seed=1,
                                max_forgetting_pct=100, ewc_lambda_init=1))
    for i in range(30): c2.propose_training(CTX, f't{i}', X, y, X, y, epochs=1)
    print("  candidatos pendentes em RAM apos 30 propostas sem aprovar:", len(c2.candidates))
    db.close()

# E8 ------------------------------------------------------------------
secao("E8  Latencia de recall x numero de memorias ativas")
for n in (200, 1000, 3000):
    with tempfile.TemporaryDirectory() as tmp:
        db = novo_db(tmp)
        with db.transaction():
            for i in range(n):
                mid = f'id{i}'
                db.db.execute("INSERT INTO memory VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (mid, *CTX.scope, '', 'personal', '', f'cliente{i} pediu orcamento numero{i} pintura externa fachada',
                     '[]', 'semantic', 'user_assertion', 'active', 0.5, '', 0, None, None, 1.0, 1.0, None, None, f'fp{i}'))
                if hasattr(db, '_index_memory'):
                    db._index_memory(mid, f'cliente{i} pediu orcamento numero{i} pintura externa fachada', [])
        t = time.perf_counter()
        for _ in range(5): db.recall(CTX, 'Qual o orcamento do cliente7 numero7 pintura?')
        print(f"  n={n:5d}: {(time.perf_counter() - t) / 5 * 1000:8.1f} ms por recall")
        db.close()

# E9 ------------------------------------------------------------------
secao("E9  Fisher empirico (rotulo verdadeiro) vs exato (esperanca sobre as classes)")
r = np.random.RandomState(0)
X = r.normal(size=(400, 6)); w = r.normal(size=6)
y = np.eye(2)[(X @ w > 0).astype(int)]
m = MCRAIEngine(6, 16, 2, seed=3, max_forgetting_pct=100, ewc_lambda_init=1, state_path='/tmp/_nao_usado.json')
m.learn('t1', X, y, X, y, epochs=120, lr=0.1)
emp = m._compute_fisher(m.W, X, y, n_samples=400)

def fisher_exato(model, X):
    W = model.W; F = {k: np.zeros_like(v) for k, v in W.items()}
    for i in range(len(X)):
        x = X[i:i + 1]; z1 = x @ W['W1'] + W['b1']; a1 = model.mcr.forward(z1)
        p = softmax(a1 @ W['W2'] + W['b2'])
        for c in range(model.n_classes):
            yt = np.zeros((1, model.n_classes)); yt[0, c] = 1
            dz2 = p - yt; dW2 = a1.T @ dz2; da1 = dz2 @ W['W2'].T
            dz1 = da1 * model.mcr.gradient(z1); dW1 = x.T @ dz1
            F['W1'] += p[0, c] * dW1 ** 2; F['W2'] += p[0, c] * dW2 ** 2
            F['b1'] += p[0, c] * dz1 ** 2; F['b2'] += p[0, c] * dz2 ** 2
    return {k: v / len(X) for k, v in F.items()}

ex = fisher_exato(m, X)
print(f"  acuracia na tarefa 1: {m.evaluate(X, y):.3f}")
print(f"  soma do Fisher empirico: {sum(v.sum() for v in emp.values()):.5f}")
print(f"  soma do Fisher exato   : {sum(v.sum() for v in ex.values()):.5f}")

# E10 -----------------------------------------------------------------
secao("E10  EWC com lambda alto: o treino diverge?")
import warnings
warnings.simplefilter('ignore')
from bench import tarefas
for lam in (100.0, 300.0):
    falhas = 0
    for s_ in range(6):
        eng = MCRAIEngine(13, 24, 2, seed=s_, max_forgetting_pct=100, ewc_lambda_init=lam, state_path='/tmp/_audit_e10.json')
        try:
            for i, ((a, b), (c, d)) in enumerate(tarefas(100 + s_)):
                eng.learn(f't{i}', a, b, c, d, epochs=40, lr=0.05)
        except RuntimeError:
            falhas += 1
    print(f"  lambda={lam:5.0f}: {falhas}/6 sementes terminam em 'pesos nao finitos'")
