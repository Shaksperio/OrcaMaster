# Cowila v10 — evolução do v9 (algoritmo Python para análise de A.C.P.)

Entrega de código local em 03/10/2026. Ainda não integrada ao Worker publicado.
A v10 parte do v9 enviado em 02/10/2026; o original é o MCR-AI Engine v8 (cópia intacta incluída).
Os 25 testes do v9 continuam passando **sem alteração**; a v10 acrescenta 35 testes.

## O que a v10 muda — cada item foi reproduzido no v9 antes de ser corrigido

`python auditoria.py` reproduz os defeitos (rode na pasta do v9 e na do v10); `python bench.py` mede as comparações.

| # | Defeito reproduzido no v9 | Correção na v10 | Medido |
|---|---|---|---|
| 1 | `solve_bounce_gamma` com `brentq` e brackets fixos falhou em 3 de 3 parâmetros válidos testados (ex.: x0=-0,83, β=0,5, a_min=0,5) e aceitava parâmetros com **dois pontos críticos** (a_min·γ > 1) | γ por Lambert W (forma fechada); recusa a_min·γ ≥ 1; verificação com Hessiana analítica, tolerância 1e-9 e unicidade do mínimo | γ padrão idêntico ao v9 (diferença < 1e-12); 3/3 resolvidos; caso a_min·γ=1,05 recusado |
| 2 | Recuperação errava acento e plural: "memoria" ≠ "memória", "orçamento" ≠ "orçamentos" | Tokenização sem acento, plural normalizado, stopwords ampliadas (aplicadas a consulta e registro) | acerto@1 **4/9 → 9/9**; falsos positivos 0/7 → 0/7 |
| 3 | `recall` varria todas as memórias e refazia o vetor da consulta por memória | Índice de tokens no SQLite (reconstruído sozinho em bancos v9) e pré-seleção por cobertura mínima de cada cláusula | 3.000 memórias: **112 → 24 ms** (corpus adversarial), **95 → 12 ms** (diverso). Resultado idêntico à varredura completa (teste de equivalência) |
| 4 | Texto apagado por `forget`/`clear_chat` continuava no arquivo `-wal` enquanto a conexão estava aberta | `PRAGMA secure_delete=ON` e `wal_checkpoint(TRUNCATE)` após `forget`, `delete_derived`, `clear_chat`, `purge_expired_turns` e retirada de consentimento | marcador apagado: presente em `m.db-wal` → ausente de todos os arquivos |
| 5 | `DeterministicMath`: `1/0` levantava `decimal.DivisionByZero` (não é `ValueError`), expressão malformada levantava `SyntaxError`, `1e2*3` devolvia `'3E+2'` | Tudo vira `ValueError`; saída posicional (`'300'`) | `1/0`, `0/0`, `1 +` → `ValueError`; `1e2*3` → `'300'` |
| 6 | Proposta de treino **inválida** já vinculava o motor ao escopo de quem a fez; candidatos pendentes acumulavam sem limite (cópia profunda do motor em RAM cada) | Vinculação só após treino bem-sucedido; máximo de 8 pendentes por escopo, validade de 1 h, `discard_training()` | 30 propostas → 8 retidas; usuário B deixa de ser bloqueado por falha de A |
| 7 | Com `ewc_lambda_init=300` (o padrão) o passo explícito da penalidade EWC diverge quando lr·λ·F > 2 e o treino termina em "pesos não finitos"; o retry ainda triplica λ | Passo proximal (semi-implícito), estável para qualquer λ e igual ao explícito quando lr·λ·F é pequeno | benchmark de 5 tarefas: **6/6 sementes divergiam → 0/6** |
| 8 | "Sim" no meio de uma conversa injetava o checkpoint do projeto no contexto | "Sim" só retoma em conversa vazia; "Continue"/"Onde paramos?" continuam retomando sempre | teste dedicado |

### Novo: `Cerebelo` e `Cowila.answer_verified()`

O adaptador de linguagem redige; a memória aprovada ancora; o `Cerebelo` recalcula o que é checável e o Cowila só entrega o que **não foi refutado**:

- aritmética (`a + b = c`, formato brasileiro `1.234,50`, `×`/`x`/`÷`) e "X% de Y é Z", recalculadas com `DeterministicMath` (Decimal);
- citações `[id]` de memória: só valem se a memória está no contexto aprovado;
- afirmar que lembra ("você me disse…") sem nenhuma memória ou turno no contexto é refutado (há guarda para negação: "não me lembro").

Rascunho refutado volta ao adaptador com os achados em `verification_feedback` (dado, não instrução de sistema). Esgotadas as tentativas (padrão 3), o Cowila **se abstém** (`status: abstained`) em vez de entregar o que o cálculo contradiz. Se nada no texto é verificável, o status é `unchecked` — **ausência de refutação não é confirmação**. Números ambíguos (`3.141`: milhar ou decimal?) são `unverifiable`, nunca refutados. Ver `demo_verificacao.py`.

### Novo e opcional: `MCRAIEngine(..., fisher_mode="exact")`

Fisher exato (esperança sobre as classes preditas) em vez do empírico com rótulo verdadeiro. Verificado contra uma implementação por amostra (`rtol=1e-10`) e, com o modelo acertando 100%, o exato soma 2,69 contra 0,72 do empírico. **Não há vantagem demonstrada**: no benchmark de aprendizado contínuo (10 sementes) o exato se comporta como um λ maior — mesma curva esquecimento × acurácia dentro do ruído. Por isso o padrão continua `"empirical"`; checkpoints v8/v9 abrem como `empirical`.

### O que a v10 NÃO decide por você

- **λ do EWC.** No benchmark sintético (5 tarefas lineares conflitantes, 10 sementes), λ=300 (o padrão, mantido) cai para 0,768 de acurácia final contra 0,816 em λ=30, e o esquecimento vai de 0,135 (λ=0) para 0,05 (λ=30) e 0,003 (λ=300): o padrão remove esquecimento e perde plasticidade. O laço de retry já sobe λ sozinho quando o esquecimento passa de `max_forgetting_pct`, então começar menor é coerente — mas isso depende dos seus dados; calibre com tarefas reais antes de mudar o padrão.
- **Migração.** Bancos v9 são reindexados na primeira abertura; checkpoints v8/v9 abrem (vetores da memória do motor são recalculados). O recall da v10 é deliberadamente mais permissivo com acento/plural: ele pode devolver registros que o v9 não devolvia (nos 7 negativos do benchmark, nenhum falso positivo).
- **Limites herdados do v9** (continuam valendo): lista abaixo em "Limites e integração pendente".

### Limites específicos da v10

- O índice guarda os **tokens** das memórias em texto claro no SQLite (como o próprio texto); são removidos em `forget`/`delete_derived`, mas permanecem para memórias `revoked`/`superseded`, igual ao texto delas.
- A exclusão segura cobre os arquivos `.db` e `-wal`; **não alcança backups, snapshots de disco nem cópias fora do SQLite**.
- As heurísticas do `Cerebelo` são exatas para aritmética e citações; a de "lembrança" é uma regra lexical em português, com falsos negativos esperados. Não verifica fatos do mundo nem dados comerciais.
- Os benchmarks são sintéticos e pequenos (inclusive o de aprendizado contínuo); não medem qualidade cognitiva.

## O que o v9 já fazia (mantido)

O objetivo central é que conhecimentos e pendências aprovados pertençam ao usuário e ao projeto, e não a uma janela de chat. O modelo de linguagem recebe memórias selecionadas ao preparar cada resposta. Isso produz continuidade entre conversas sem depender de manter o histórico inteiro no prompt.

| Parte | Implementação nesta revisão |
|---|---|
| Ativação MCR V6 original | Fórmula e parâmetros preservados; verificação do ponto de mínimo e validação de parâmetros |
| Memória persistente | SQLite transacional, separado do JSON de pesos neurais |
| Isolamento | Empresa, usuário autenticado, finalidade e projeto; dados globais do usuário são permitidos no mesmo escopo |
| Memória entre conversas | Fatos aprovados recuperáveis em novas sessões; checkpoint aprovado retoma projeto por “Continue” ou “Onde paramos?” |
| Chat apagado | Remove turnos da conversa e preserva memória aprovada; exclusão derivada é outra operação explícita |
| Candidatos e aprovação | Proposta não entra no contexto; revisão explícita ativa ou rejeita |
| Categorias | Episódica, semântica, procedural, erro, preferência, projeto, hipótese e pós-debate |
| Origem | IDs da conversa/mensagem, evidência, tipo de afirmação, confiança informada, datas e versão anterior |
| Correções e conflitos | Chave de fato detecta revisões estruturadas; substituição só após aprovação, com anterior marcada como superada |
| Consentimento | Granular por finalidade; retirada impede uso e marca memórias como revogadas; nova concessão não reativa registros antigos |
| Exclusão/retenção | Memória apagada perde conteúdo/aliases/evidência; turnos têm expiração e limpeza explícita |
| Recuperação conservadora | Cosseno lexical ≥0,30, ≥2 termos compartilhados, cobertura ≥70%, até três registros, aliases e cláusulas independentes |
| Menção genérica a “memória” | Não libera a listagem indiscriminada de todas as memórias |
| Resumo entre sessões | `propose_consolidation()` usa adaptador de resumo e gera candidato; `checkpoint()` permite resumo escrito pelo usuário |
| Aprendizado de erros | `record_error()` cria lição candidata com correção proposta, sem alterar pesos/política |
| Contexto | Até 12 turnos, 4.000 caracteres por turno e orçamento total em caracteres, com descarte informado |
| Dados comerciais | Porta `live_data` restrita a capacidade `business.read`, para dados atuais filtrados pelo servidor |
| Ações comerciais | Lista permitida, validador externo, proposta revisável, confirmação vinculada ao conteúdo, validade de cinco minutos e uso único |
| Matemática | Decimal para aritmética, porcentagem por expressão, área/perímetro/volume e desconto de aberturas; sem `eval` |
| Feedback e baseline | Avaliação registrada sem retreinar; contexto baseline exclui memória de longo prazo |
| EWC/replay | Núcleo original preservado; Fisher médio, replay e medição de esquecimento |
| Checkpoint neural | Pesos, Fisher, replay, conjuntos de avaliação, configuração e RNG local salvos por substituição atômica |
| Treinamento | Candidato em cópia; rejeição por esquecimento excessivo/dados inválidos/valores não finitos; aprovação separada para mudar estado ativo |
| Identidade | `AuthContext` vem do servidor; nome digitado na conversa não concede privilégios |

## Arquivos

- `cowila.py`: coordenação, memória, consentimento, contexto, ações, cálculos e `Cerebelo`.
- `mcr_neural.py`: motor neural derivado do original, com as correções do v9 e da v10.
- `mcr_ai_engine_v8_original.py`: cópia original intacta para comparação.
- `test_cowila.py`: 25 testes do v9, sem alteração. `test_cowila_v10.py`: 35 testes da v10.
- `auditoria.py`: reproduz os defeitos do v9 (rode nas duas pastas). `bench.py`: latência, qualidade de recuperação e aprendizado contínuo.
- `demo.py`: apaga chat, reabre banco e retoma o projeto em conversa nova. `demo_verificacao.py`: etapa de verificação.
- `requirements.txt`: dependências já utilizadas pelo motor original.
- `TESTES.txt`: resultado real da execução dos testes.

## Executar

Python 3.10 ou superior; validado aqui em Python 3.12.

```bash
python -m pip install -r requirements.txt
python -m unittest -v test_cowila test_cowila_v10
python demo.py
python demo_verificacao.py
```

## Fluxo de memória

1. O servidor autentica o usuário e constrói `AuthContext` a partir da sessão e das capacidades do plano. Nunca aceite esses campos como autoridade fornecida pelo frontend ou pelo chat.
2. A interface registra o consentimento para a finalidade de persistência antes de guardar conversas ou candidatos de memória.
3. O servidor abre `PersistentMemory` em um caminho durável. Todas as conversas do mesmo usuário/projeto apontam para esse armazenamento.
4. `append_turn()` guarda o histórico com retenção definida.
5. `propose()` ou `propose_consolidation()` cria candidato. Não há aprovação automática.
6. A interface exibe `inspect()` e `conflicts()` e transmite a decisão explícita para `review()`.
7. Em cada resposta, `Cowila.context()` recupera memórias aprovadas e contexto recente.
8. A aplicação fornece um adaptador de linguagem a `answer(model=...)` se desejar redação generativa. Sem adaptador, o método devolve os registros encontrados com suas fontes.
9. “Continue” em um chat novo retoma o último checkpoint aprovado do projeto explicitamente selecionado.

A aprovação pode ser um botão de salvar/revisar memória na aplicação. Não é necessário pedir confirmação para cada pergunta; o controle ocorre quando se ativa uma memória ou uma ação. Esta proposta não armazena silenciosamente todas as mensagens como verdades duradouras.

## Separação entre modelo neural, memória e modelo de linguagem

O `MCRAIEngine` original é uma pequena rede de classificação, não um modelo generativo de linguagem. EWC e replay protegem seu aprendizado de tarefas numéricas. Não alteram os pesos da Gemma usada pelo Worker.

A continuidade textual é resolvida por memória externa, resumo aprovado, recuperação e contexto. Na aplicação, o adaptador deve mapear `rules` para instruções de sistema e os demais campos para dados sem autoridade. O registro de uma “instruction” descreve o conteúdo memorizado; não o transforma em permissão ou regra de sistema.

A similaridade lexical não é uma probabilidade de verdade. A confiança é um metadado atribuído pelo fluxo de revisão, com evidência. Uma afirmação do usuário permanece identificada como `user_assertion`.

## Aprendizado neural

Use uma instância e um arquivo de estado neural por escopo autenticado. A primeira proposta vincula o motor ao escopo; essa vinculação persiste quando aprovada e bloqueia uso de treinamento por outra identidade. Não use um estado legado pessoal como motor global compartilhado.

`propose_training()` trabalha numa cópia. `approve_training()` exige capacidade específica, verifica se o candidato ainda corresponde ao estado ativo e salva antes de trocar a referência. As propostas neurais pendentes ficam em RAM nesta entrega: reiniciar o processo exige propor novamente; o estado aprovado é durável. Instâncias paralelas de treinamento do mesmo modelo precisam de coordenação adicional no backend; a trava implementada é por instância de processo.

O treinamento mede esquecimento nos conjuntos de avaliação anteriores e rejeita o candidato quando excede o limite, mesmo ao terminar as tentativas. Isso não garante boa precisão na tarefa nova: a revisão ainda deve avaliar as métricas e conjuntos representativos. Os testes demonstram comportamento funcional, não uma comparação de qualidade cognitiva com um LLM.

O v8 não guardava conjuntos de avaliação no checkpoint. O carregamento mantém pesos, memória e replay legados, mas bloqueia novo treino quando há histórico sem conjuntos de avaliação. Esses dados devem ser restaurados de fonte real, não fabricados. `import_legacy()` importa memória textual de forma aditiva e pendente de revisão.

## Limites e integração pendente

- Esta revisão entrega o Python para análise. Não publica nem altera o Worker, o repositório, os bindings, a autenticação ou os assets.
- O serviço TypeScript original chama `runner.py` sem identidade nem projeto. Ele precisa de adaptação autenticada para usar esta API; apontá-lo diretamente para o novo módulo não resolve a integração.
- O caminho SQLite/JSON precisa ficar em volume durável com acesso restrito, backups e uma política de retenção. Apagar conteúdo da tabela não garante destruição das cópias antigas em WAL, páginas livres ou backups.
- O consentimento no código é um controle operacional; a infraestrutura e o aplicativo fornecem autenticação real e o fluxo de decisão do usuário.
- Memórias sensíveis ficam fora do contexto. A regex de segredos é uma barreira limitada; o adaptador deve classificar sensibilidade e filtrar dados atuais/anexos. Não é um detector universal de informações privadas.
- A recuperação continua lexical e usa aliases; não inclui embeddings, tradução de sinônimos ou detector geral de contradições. Conflitos são identificados quando os registros compartilham a mesma chave estruturada.
- O orçamento é em caracteres, não tokens do modelo. O adaptador deve aplicar também o limite real do provedor.
- Não há promessa de defesa completa contra prompt injection ou de verificação automática da verdade de toda resposta gerada. As ações passam por validação externa; a redação do adaptador precisa dos filtros de entrada/saída da aplicação.
- `live_data` deve ser filtrado pelo servidor por empresa e usuário, atualizado e identificado com data de origem. O Python não consulta sozinho preços, pagamento, recibos ou bancos de produção.
- O backend deve revalidar permissões vigentes, escopo e dados no `validator`. O frontend deve enviar o digest somente após uma confirmação real do usuário, por rota autenticada. O handler precisa ser idempotente pelo ticket. Se falhar depois de um efeito externo, o código não tenta repetir automaticamente.
- As rotinas de blog, extração de arquivos, pesquisa externa, planos, pagamento e lembretes continuam integrações da aplicação. Não foram convertidas para este motor como se fossem capacidades neurais. A lista de ações não inclui envios por Resend, e nenhum envio ou integração externa foi executado nesta revisão.

## Evidência de continuidade

O teste `test_restart_and_new_chat_after_chat_deletion` cria conversa e checkpoint, confirma o resumo, apaga o chat, fecha/reabre o banco, cria uma nova conversa e recupera a pendência com “Continue”. Em seguida, exclui explicitamente as memórias derivadas e confirma que elas deixam de ser recuperáveis. O histórico da conversa nova começa vazio.

Isso demonstra memória entre sessões quando há conhecimento aprovado persistido. Sem memória salva ou checkpoint aprovado, o Cowila deve informar que não tem contexto suficiente — não inventar que se lembra.

O teste `test_memory_recovered_in_separate_python_process` também abre o mesmo banco em outro processo Python e confirma a recuperação da memória autorizada.
