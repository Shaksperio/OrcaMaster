"""MCR-AI Engine v10, derivado do Python v8 fornecido por A.C.P. (v9 = revisao anterior).
Mantem MCRActivationV6, EWC com media de Fisher, replay e memoria lexical.

Mudancas da v10 neste modulo (cada uma tem teste em test_cowila_v10.py):
  - gamma por Lambert W (solucao fechada) no lugar de brentq com brackets fixos, que falhava
    em parametros validos; recusa parametros que criam um segundo ponto critico;
  - verificacao da MCR com Hessiana analitica, tolerancia estrita e unicidade do minimo;
  - Fisher exato (esperanca sobre as classes) como opcao `fisher_mode`; o v9 usava o Fisher
    empirico, que subestima a importancia dos pesos quando o modelo ja acerta;
  - tokenizacao sem acento e com plural normalizado (a recuperacao v9 errava "memoria"/"memória");
  - replay concatenado uma vez por treino em vez de a cada lote.
Alegacoes de benchmarks do cabecalho v8 nao sao resultados desta revisao.
A governanca de memoria/treino fica em cowila.py.
"""
import json, os, re, time
import tempfile
import copy
import unicodedata
import numpy as np
from scipy.special import lambertw


# ------------------------------------------------------------------ #
# 1) ATIVACAO
# ------------------------------------------------------------------ #
def solve_bounce_gamma(x0, beta, a_min, gamma_search_max=50.0):
    """Resolve a_min*g*exp(g*x0) = exp(-beta*x0^2)*(1-2*beta*x0^2) em forma fechada.

    Com z = (lhs/a_min)*x0, a equacao vira (g*x0)*exp(g*x0) = z, logo g = W(z)/x0.
    O ramo principal W0 da a MENOR raiz (g <= -1/x0). A outra raiz (ramo W-1) existe, mas
    leva a a_min*g > 1, isto e, f'(0-) < 0 e um segundo ponto critico entre x0 e 0.
    """
    if not all(np.isfinite(v) for v in (x0, beta, a_min, gamma_search_max)) or x0 >= 0 or beta <= 0 or a_min <= 0 or gamma_search_max <= 0:
        raise ValueError("Parametros de ativacao invalidos")
    s = beta * x0 ** 2
    lhs = float(np.exp(-s) * (1 - 2 * s))
    if lhs <= 0:
        raise ValueError(f"beta={beta} grande demais para x0={x0}. Use beta < {1/(2*x0**2):.4f}.")
    z = lhs / a_min * x0
    if z <= -1.0 / np.e:
        raise ValueError(f"Sem raiz real: exige a_min > {lhs * np.e * abs(x0):.6f} (ou reduza beta).")
    gamma = float(lambertw(z, k=0).real / x0)
    if not np.isfinite(gamma) or gamma <= 0 or gamma > gamma_search_max:
        raise ValueError("gamma fora do intervalo permitido")
    if a_min * gamma >= 1.0:
        raise ValueError(f"a_min*gamma={a_min * gamma:.4f} >= 1: x0 deixa de ser o unico ponto critico. Reduza a_min.")
    return gamma


class MCRActivationV6:
    def __init__(self, x0=-0.83, beta=0.5, a_min=0.8):
        self.x0, self.beta, self.a_min = x0, beta, a_min
        self.gamma = solve_bounce_gamma(x0, beta, a_min)
        self._verify()

    def _verify(self):
        fp = float(self.gradient(np.array([self.x0]))[0])
        fpp = float(self.hessian(np.array([self.x0]))[0])
        if abs(fp) > 1e-9 or fpp <= 0:
            raise RuntimeError("Auto-verificacao da MCR falhou.")
        # x0 deve ser o unico ponto critico em x<0 (um unico cruzamento de sinal de f').
        grid = np.linspace(min(-8.0, 3.0 * self.x0), -1e-6, 100_001)
        sgn = np.sign(self.gradient(grid)); sgn = sgn[sgn != 0]
        if np.count_nonzero(np.diff(sgn)) != 1:
            raise RuntimeError("Auto-verificacao da MCR falhou: x0 nao e o unico ponto critico.")

    def forward(self, x):
        x = np.asarray(x, dtype=float)
        xn = np.minimum(x, 0.0)
        neg = xn * np.exp(-self.beta * xn**2) - self.a_min * np.expm1(self.gamma * xn)
        return np.where(x >= 0.0, x, neg)

    def gradient(self, x):
        x = np.asarray(x, dtype=float)
        pos_grad = np.ones_like(x)
        xn = np.minimum(x, 0.0)
        neg_grad = (np.exp(-self.beta * xn**2) * (1.0 - 2.0*self.beta*xn**2)
                    - self.a_min * self.gamma * np.exp(self.gamma * xn))
        return np.where(x >= 0.0, pos_grad, neg_grad)

    def hessian(self, x):
        """Segunda derivada analitica (0 para x>=0)."""
        x = np.asarray(x, dtype=float)
        xn = np.minimum(x, 0.0)
        b, g = self.beta, self.gamma
        neg = (np.exp(-b * xn**2) * (-2.0 * b * xn) * (3.0 - 2.0 * b * xn**2)
               - self.a_min * g**2 * np.exp(g * xn))
        return np.where(x >= 0.0, 0.0, neg)


# ------------------------------------------------------------------ #
# 2) MEMORIA PERSISTENTE
# ------------------------------------------------------------------ #
TOKENIZER_VERSION = "2"  # muda quando _tokenize muda: indices persistidos precisam ser refeitos


def _fold(text):
    """Minusculas e sem acentos: 'Memória' e 'memoria' viram o mesmo token."""
    t = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in t if not unicodedata.combining(c))


_STOPWORDS = {_fold(w) for w in (
    "o a os as de da do das dos e em um uma uns umas no na nos nas ao aos à às que qual quais "
    "com se é foi era são sao está esta estão estao ser ter tem há ha para por pelo pela pelos pelas "
    "como mais menos meu minha meus minhas seu sua seus suas sobre isso isto esse essa esses essas "
    "este estes estas ou mas já ja até ate entre quando onde quem quanto quantos quantas").split()}


def _stem(tok):
    """Normalizacao leve de plural em portugues; aplicada igualmente a consulta e ao registro."""
    if tok.isdigit() or any(c.isdigit() for c in tok) or len(tok) <= 3:
        return tok
    if tok.endswith("oes") and len(tok) > 5:
        return tok[:-3] + "ao"
    if tok.endswith("ns"):
        return tok[:-2] + "m"
    if tok.endswith("ais") and len(tok) > 4:
        return tok[:-3] + "al"
    if tok.endswith("eis") and len(tok) > 4:
        return tok[:-3] + "el"
    if (tok.endswith("res") or tok.endswith("zes")) and len(tok) > 4:
        return tok[:-2]
    if tok.endswith("s") and not tok.endswith(("ss", "us", "is")):
        return tok[:-1]
    return tok


def _tokenize(text):
    toks = re.findall(r"[a-z0-9_]+", _fold(text))
    return [_stem(t) for t in toks if len(t) > 1 and t not in _STOPWORDS]


class MemoryStore:
    def __init__(self):
        self.entries = []

    def _embed(self, text):
        toks = _tokenize(text)
        vec = {}
        for t in toks:
            vec[t] = vec.get(t, 0) + 1
        norm = np.sqrt(sum(v*v for v in vec.values())) or 1.0
        return {k: v/norm for k, v in vec.items()}

    @staticmethod
    def _cosine(v1, v2):
        common = set(v1) & set(v2)
        return sum(v1[k]*v2[k] for k in common)

    def remember(self, text, meta=None):
        meta = meta or {}
        # Aliases opcionais permitem registrar formas de pergunta conhecidas
        # sem reduzir o limiar global de abstencao.
        aliases = meta.get("aliases", [])
        index_text = text + " " + " ".join(str(a) for a in aliases)
        self.entries.append({"text": text, "vec": self._embed(index_text), "meta": meta})

    def recall(self, query, top_k=3, min_score=0.30,
               min_shared_tokens=2, min_query_coverage=0.70):
        """Recuperacao conservadora: prefere abstencao a falso recall.

        O cosseno sozinho aceita coincidencias acidentais de uma palavra
        (ex.: "Vhariel" em uma pergunta sobre assassinato recuperando uma
        memoria sobre uma espada). Exigimos evidencias independentes:
        similaridade, quantidade minima de tokens compartilhados e cobertura
        minima dos termos da consulta.
        """
        qvec = self._embed(query)
        qtokens = set(qvec)
        if not qtokens:
            return []

        scored = []
        for e in self.entries:
            etokens = set(e["vec"])
            shared = qtokens & etokens
            score = self._cosine(qvec, e["vec"])
            coverage = len(shared) / len(qtokens)
            if (score >= min_score and
                    len(shared) >= min_shared_tokens and
                    coverage >= min_query_coverage):
                scored.append((score, coverage, len(shared), e))

        scored.sort(key=lambda s: (-s[0], -s[1], -s[2]))
        return [(score, e["text"]) for score, _, _, e in scored[:top_k]]

    def to_dict(self):
        return {"entries": self.entries}

    @classmethod
    def from_dict(cls, d):
        m = cls()
        m.entries = d.get("entries", [])
        # Vetores gravados por versoes anteriores usam outra tokenizacao: refaz a partir do texto.
        for e in m.entries:
            aliases = e.get("meta", {}).get("aliases", [])
            e["vec"] = m._embed(e["text"] + " " + " ".join(str(a) for a in aliases))
        return m


def softmax(x):
    e = np.exp(x - np.max(x, axis=1, keepdims=True))
    return e / np.sum(e, axis=1, keepdims=True)


# ------------------------------------------------------------------ #
# 3) MOTOR INTEGRADO (EWC com fisher em MEDIA MOVEL + REPLAY + MEMORIA)
# ------------------------------------------------------------------ #
class MCRAIEngine:
    def __init__(self, n_features, n_hidden, n_classes,
                 x0=-0.83, beta=0.5, a_min=0.8, seed=42,
                 max_forgetting_pct=15.0, ewc_lambda_init=300.0,
                 replay_size_per_task=40, replay_ratio=0.3,
                 state_path="mcr_engine_state.json", fisher_mode="empirical"):
        if any(not isinstance(v, int) or isinstance(v, bool) or v < 1 for v in (n_features, n_hidden, n_classes, replay_size_per_task)):
            raise ValueError("Dimensoes e tamanho do replay devem ser inteiros positivos")
        if not 0 <= replay_ratio <= 1 or not 0 <= max_forgetting_pct <= 100 or not np.isfinite(ewc_lambda_init) or ewc_lambda_init < 0:
            raise ValueError("Configuracao neural invalida")
        if fisher_mode not in ("empirical", "exact"):
            raise ValueError("fisher_mode deve ser 'empirical' ou 'exact'")
        self.fisher_mode = fisher_mode
        self.mcr = MCRActivationV6(x0=x0, beta=beta, a_min=a_min)
        self.n_features, self.n_hidden, self.n_classes = n_features, n_hidden, n_classes
        self.max_forgetting_pct = max_forgetting_pct
        self.ewc_lambda_init = ewc_lambda_init
        self.replay_size_per_task = replay_size_per_task
        self.replay_ratio = replay_ratio
        self.state_path = state_path

        self.rng = np.random.RandomState(seed)
        r = self.rng
        self.W = {
            'W1': r.randn(n_features, n_hidden) * np.sqrt(2.0/n_features),
            'b1': np.zeros((1, n_hidden)),
            'W2': r.randn(n_hidden, n_classes) * np.sqrt(2.0/n_hidden),
            'b2': np.zeros((1, n_classes)),
        }
        self.fisher_accum = None   # MEDIA MOVEL (nao soma) -- evita explosao com muitas tarefas
        self.n_tasks_in_fisher = 0
        self.W_star = None
        self.tasks = {}
        self.replay_buffer = {}
        self.task_history = []
        self.memory = MemoryStore()

        if os.path.exists(state_path):
            self.load()

    def _forward(self, X, W=None):
        W = W or self.W
        z1 = X @ W['W1'] + W['b1']
        a1 = self.mcr.forward(z1)
        p = softmax(a1 @ W['W2'] + W['b2'])
        return z1, a1, p

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.n_features or not np.isfinite(X).all():
            raise ValueError("Entrada de previsao invalida")
        _, _, p = self._forward(X)
        return p

    def evaluate(self, X, y, W=None):
        _, _, p = self._forward(X, W)
        return float(np.mean(np.argmax(p, axis=1) == np.argmax(y, axis=1)))

    def _replay_arrays(self):
        """Replay de todas as tarefas concatenado UMA vez (o v9 refazia isto a cada lote)."""
        if not self.replay_buffer:
            return None, None
        return (np.concatenate([v[0] for v in self.replay_buffer.values()], axis=0),
                np.concatenate([v[1] for v in self.replay_buffer.values()], axis=0))

    def _build_replay_batch(self, batch_size, arrays=None):
        all_X, all_y = arrays if arrays is not None else self._replay_arrays()
        if all_X is None:
            return None, None
        n = min(batch_size, len(all_X))
        idx = self.rng.choice(len(all_X), n, replace=False)
        return all_X[idx], all_y[idx]

    def _train_epochs(self, X, y, epochs, lr, batch, ewc_lambda, W_snapshot):
        n = len(X)
        W = {k: v.copy() for k, v in W_snapshot.items()}
        replay_batch_size = max(1, int(batch * self.replay_ratio))
        replay = self._replay_arrays()

        for ep in range(epochs):
            idx = self.rng.permutation(n)
            for i in range(0, n, batch):
                b = idx[i:i+batch]
                Xb, yb = X[b], y[b]

                if replay[0] is not None:
                    Xr, yr = self._build_replay_batch(replay_batch_size, replay)
                    if Xr is not None:
                        Xb = np.concatenate([Xb, Xr], axis=0)
                        yb = np.concatenate([yb, yr], axis=0)

                z1 = Xb @ W['W1'] + W['b1']
                a1 = self.mcr.forward(z1)
                p = softmax(a1 @ W['W2'] + W['b2'])
                dz2 = (p - yb) / len(Xb)
                dW2 = a1.T @ dz2; db2 = np.sum(dz2, axis=0, keepdims=True)
                da1 = dz2 @ W['W2'].T
                dz1 = da1 * self.mcr.gradient(z1)
                dW1 = Xb.T @ dz1; db1 = np.sum(dz1, axis=0, keepdims=True)

                grads = {'W1': dW1, 'b1': db1, 'W2': dW2, 'b2': db2}
                if self.fisher_accum is None:
                    for k, g in grads.items():
                        W[k] -= lr * g
                else:
                    # Passo proximal da penalidade EWC (semi-implicito):
                    #   w <- (w - lr*g + lr*lam*F*w*) / (1 + lr*lam*F)
                    # E o argmin de ||w-(w-lr*g)||^2/(2lr) + lam*F*(w-w*)^2/2. Equivale ao passo explicito do v9
                    # quando lr*lam*F e pequeno, mas nao diverge quando lr*lam*F > 2 (o v9 gerava pesos nao
                    # finitos com ewc_lambda_init=300 e o laco de retry ainda triplicava o lambda).
                    for k, g in grads.items():
                        c = lr * ewc_lambda * self.fisher_accum[k]
                        W[k] = (W[k] - lr * g + c * self.W_star[k]) / (1.0 + c)
        return W

    def _fisher_exact(self, W, X):
        """Fisher exato: E_{c ~ p(.|x)} [grad log p(c|x)^2], somando sobre as classes.

        Usa a distribuicao PREDITA pelo modelo, nao o rotulo verdadeiro. Com rotulo verdadeiro
        (Fisher empirico) o gradiente tende a zero quando o modelo ja acerta e a penalidade EWC
        deixa de proteger justamente os pesos que sustentam a tarefa aprendida.
        """
        z1 = X @ W['W1'] + W['b1']
        a1 = self.mcr.forward(z1)
        g1 = self.mcr.gradient(z1)
        p = softmax(a1 @ W['W2'] + W['b2'])
        F = {k: np.zeros_like(v) for k, v in W.items()}
        x2, a2 = X ** 2, a1 ** 2
        for c in range(self.n_classes):
            dz2 = p.copy(); dz2[:, c] -= 1.0          # p - onehot(c)
            wc = p[:, c:c + 1]
            dz2sq = dz2 ** 2
            dz1sq = ((dz2 @ W['W2'].T) * g1) ** 2
            F['W2'] += (a2 * wc).T @ dz2sq
            F['b2'] += (wc * dz2sq).sum(axis=0, keepdims=True)
            F['W1'] += (x2 * wc).T @ dz1sq
            F['b1'] += (wc * dz1sq).sum(axis=0, keepdims=True)
        for k in F:
            F[k] /= len(X)
        return F

    def _compute_fisher(self, W, X, y, n_samples=200, mode=None):
        mode = mode or getattr(self, "fisher_mode", "empirical")
        if mode == "exact":
            idx = self.rng.choice(len(X), min(n_samples, len(X)), replace=False)
            return self._fisher_exact(W, X[idx])
        fisher = {k: np.zeros_like(v) for k, v in W.items()}
        idx = self.rng.choice(len(X), min(n_samples, len(X)), replace=False)
        for i in idx:
            x = X[i:i+1]; yt = y[i:i+1]
            z1 = x @ W['W1'] + W['b1']
            a1 = self.mcr.forward(z1)
            p = softmax(a1 @ W['W2'] + W['b2'])
            dz2 = (p - yt)
            dW2 = a1.T @ dz2; db2 = dz2
            da1 = dz2 @ W['W2'].T
            dz1 = da1 * self.mcr.gradient(z1)
            dW1 = x.T @ dz1; db1 = dz1
            fisher['W1'] += dW1**2; fisher['b1'] += db1**2
            fisher['W2'] += dW2**2; fisher['b2'] += db2**2
        for k in fisher: fisher[k] /= len(idx)
        return fisher

    def learn(self, task_name, X_train, y_train, X_test, y_test, **kwargs):
        """Rollback completo se qualquer etapa de treinamento falhar."""
        if getattr(self, "legacy_evaluation_missing", False):
            raise ValueError("Checkpoint legado sem conjuntos de avaliacao")
        snapshot = copy.deepcopy(self.__dict__)
        try:
            return self._learn_impl(task_name, np.asarray(X_train, dtype=float),
                                    np.asarray(y_train, dtype=float), np.asarray(X_test, dtype=float),
                                    np.asarray(y_test, dtype=float), **kwargs)
        except BaseException:
            self.__dict__.clear(); self.__dict__.update(snapshot)
            raise

    def _learn_impl(self, task_name, X_train, y_train, X_test, y_test,
              epochs=40, lr=0.05, batch=32, max_retries=3, ewc_lambda_cap=20000.0):
        self._validate_task(X_train, y_train, X_test, y_test)
        if epochs < 1 or batch < 1 or max_retries < 1 or not np.isfinite(lr) or lr <= 0:
            raise ValueError("Parametros de treino invalidos")
        if not np.isfinite(ewc_lambda_cap) or ewc_lambda_cap <= 0 or self.ewc_lambda_init < 0:
            raise ValueError("Penalidade EWC invalida")
        acc_before = {name: self.evaluate(Xte, yte) for name, (Xte, yte) in self.tasks.items()}

        ewc_lambda = min(self.ewc_lambda_init, ewc_lambda_cap)
        attempt = 0
        while True:
            attempt += 1
            W_snapshot = self.W_star if self.W_star is not None else self.W
            W_new = self._train_epochs(X_train, y_train, epochs, lr, batch, ewc_lambda, W_snapshot)

            forgetting, worst = {}, 0.0
            for name, (Xte, yte) in self.tasks.items():
                acc_now = self.evaluate(Xte, yte, W_new)
                drop = (acc_before[name] - acc_now) * 100
                forgetting[name] = round(drop, 2)
                worst = max(worst, drop)

            if worst <= self.max_forgetting_pct or attempt >= max_retries or not self.tasks or ewc_lambda >= ewc_lambda_cap:
                break
            else:
                ewc_lambda = min(ewc_lambda * 3.0, ewc_lambda_cap)

        if worst > self.max_forgetting_pct:
            raise RuntimeError("Candidato rejeitado: esquecimento acima do limite")
        if not all(np.isfinite(v).all() for v in W_new.values()):
            raise RuntimeError("Candidato rejeitado: pesos nao finitos")
        self.W = W_new
        acc_new_task = self.evaluate(X_test, y_test)

        # MEDIA MOVEL do fisher (nao soma bruta) -- evita que ewc_lambda*fisher
        # exploda numericamente depois de muitas tarefas (bug real que apareceu
        # ao testar com 20 tarefas na versao anterior, que usava soma)
        fisher_new = self._compute_fisher(self.W, X_train, y_train)
        if not all(np.isfinite(v).all() for v in fisher_new.values()):
            raise RuntimeError("Fisher nao finito")
        if self.fisher_accum is None:
            self.fisher_accum = fisher_new
        else:
            t = self.n_tasks_in_fisher
            for k in self.fisher_accum:
                self.fisher_accum[k] = (self.fisher_accum[k] * t + fisher_new[k]) / (t + 1)
        self.n_tasks_in_fisher += 1
        self.W_star = {k: v.copy() for k, v in self.W.items()}
        self.tasks[task_name] = (X_test, y_test)

        idx = self.rng.choice(len(X_train), min(self.replay_size_per_task, len(X_train)), replace=False)
        self.replay_buffer[task_name] = (X_train[idx].copy(), y_train[idx].copy())

        avg_forgetting = float(np.mean(list(forgetting.values()))) if forgetting else 0.0
        record = {"task": task_name, "attempts": attempt, "ewc_lambda_final": ewc_lambda,
                   "acc_new_task": acc_new_task, "forgetting_pct": forgetting,
                   "avg_forgetting": avg_forgetting, "n_tasks_seen": len(self.tasks)}
        self.task_history.append(record)
        self.memory.remember(
            f"Tarefa '{task_name}' (#{len(self.tasks)}) aprendida com acuracia "
            f"{acc_new_task*100:.2f}%. Esquecimento medio nas tarefas anteriores: "
            f"{avg_forgetting:.2f} pontos percentuais."
        )
        return record

    def _validate_task(self, X_train, y_train, X_test, y_test):
        for X, y in ((X_train, y_train), (X_test, y_test)):
            if X.ndim != 2 or y.ndim != 2 or len(X) == 0 or len(X) != len(y):
                raise ValueError("Dados devem ser matrizes nao vazias com linhas correspondentes")
            if X.shape[1] != self.n_features or y.shape[1] != self.n_classes:
                raise ValueError("Dimensoes incompativeis com o modelo")
            if not np.isfinite(X).all() or not np.isfinite(y).all():
                raise ValueError("Dados nao finitos")
            if (y < 0).any() or not np.allclose(y.sum(axis=1), 1):
                raise ValueError("Rotulos devem ser distribuicoes de probabilidade")

    def remember(self, text, meta=None):
        self.memory.remember(text, meta)

    def ask(self, question, min_score=0.30):
        # Retorna apenas a melhor memoria. Misturar top-3 aumenta o risco de
        # anexar fatos irrelevantes a uma resposta correta.
        hits = self.memory.recall(question, top_k=1, min_score=min_score)
        if not hits:
            return "Não tenho isso registrado na memória — não vou inventar uma resposta."
        score, text = hits[0]
        return f"Com base no que está registrado:\n  [confiança {score:.2f}] {text}\n"

    def save(self):
        """Checkpoint atomico: inclui tarefas antigas e estado do RNG."""
        def arr(d): return {k: v.tolist() for k, v in d.items()} if d else None
        rs = self.rng.get_state()
        state = {
            "version": 10,
            "owner_scope": getattr(self, "owner_scope", None),
            "config": {"n_features": self.n_features, "n_hidden": self.n_hidden,
                       "n_classes": self.n_classes, "x0": self.mcr.x0,
                       "beta": self.mcr.beta, "a_min": self.mcr.a_min,
                       "fisher_mode": self.fisher_mode,
                       "max_forgetting_pct": self.max_forgetting_pct,
                       "ewc_lambda_init": self.ewc_lambda_init,
                       "replay_size_per_task": self.replay_size_per_task,
                       "replay_ratio": self.replay_ratio},
            "W": arr(self.W), "fisher_accum": arr(self.fisher_accum),
            "n_tasks_in_fisher": self.n_tasks_in_fisher,
            "W_star": arr(self.W_star), "task_history": self.task_history,
            "memory": self.memory.to_dict(),
            "tasks": {k: [v[0].tolist(), v[1].tolist()] for k, v in self.tasks.items()},
            "replay_buffer": {k: [v[0].tolist(), v[1].tolist()] for k, v in self.replay_buffer.items()},
            "rng": [rs[0], rs[1].tolist(), rs[2], rs[3], rs[4]],
        }
        target = os.path.abspath(self.state_path)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".mcr-", dir=os.path.dirname(target))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, allow_nan=False)
                f.flush(); os.fsync(f.fileno())
            os.replace(tmp, target)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)

    def load(self):
        with open(self.state_path, encoding="utf-8") as f:
            state = json.load(f)
        if state.get("version", 8) not in (8, 9, 10): raise ValueError("Versao de checkpoint nao suportada")
        self.owner_scope = tuple(state["owner_scope"]) if state.get("owner_scope") else None
        cfg = state.get("config", {})
        # Checkpoints anteriores a v10 foram treinados com Fisher empirico: mantem o modo para retomar igual.
        self.fisher_mode = cfg.get("fisher_mode", "empirical")
        for key in ("n_features", "n_hidden", "n_classes", "max_forgetting_pct",
                    "ewc_lambda_init", "replay_size_per_task", "replay_ratio"):
            if key in cfg: setattr(self, key, cfg[key])
        if cfg:
            self.mcr = MCRActivationV6(cfg["x0"], cfg["beta"], cfg["a_min"])
        def to_np(d): return {k: np.array(v, dtype=float) for k, v in d.items()} if d else None
        self.W = to_np(state["W"])
        expected = {"W1": (self.n_features, self.n_hidden), "b1": (1, self.n_hidden),
                    "W2": (self.n_hidden, self.n_classes), "b2": (1, self.n_classes)}
        for k, shape in expected.items():
            if self.W[k].shape != shape or not np.isfinite(self.W[k]).all():
                raise ValueError("Checkpoint neural invalido")
        self.fisher_accum = to_np(state["fisher_accum"])
        self.n_tasks_in_fisher = state.get("n_tasks_in_fisher", 0)
        self.W_star = to_np(state["W_star"])
        self.task_history = state["task_history"]
        self.memory = MemoryStore.from_dict(state["memory"])
        self.replay_buffer = {k: (np.array(v[0]), np.array(v[1])) for k, v in state.get("replay_buffer", {}).items()}
        self.tasks = {k: (np.array(v[0]), np.array(v[1])) for k, v in state.get("tasks", {}).items()}
        if self.task_history and not self.tasks:
            # O v8 nao salvava conjuntos de avaliacao: nao simular que foram recuperados.
            self.legacy_evaluation_missing = True
        if "rng" in state:
            r = state["rng"]
            self.rng.set_state((r[0], np.array(r[1], dtype=np.uint32), r[2], r[3], r[4]))
